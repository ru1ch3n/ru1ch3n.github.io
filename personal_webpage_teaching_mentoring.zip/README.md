# Website File Structure

index.html
bio.html
research.html
papers.html
teaching.html
news.html
assets/
   style.css
   Ruichen_Xu_CV.pdf
